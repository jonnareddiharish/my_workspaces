//8.2: Write a thread program to display timer where timer will get refresh after every 10 seconds. (Use Runnable implementation)

package com.capgemini.lesson8;

import java.io.Console;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class TimerThread implements Runnable 
{

	
	@Override
	public void run()
	{
		while(true)
			{	LocalDateTime ld = LocalDateTime.now();
				System.out.println(ld);
				
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
				
		
	}

	
	public static void main(String[] args) 
	{
		

		TimerThread th = new TimerThread();
		Thread t1 = new Thread(th);
		t1.start();
	}

	
}
