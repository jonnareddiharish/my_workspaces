package com.capgemini.core.oop.relation;

public interface BankInterest 
{
	void calcInterest();
}
