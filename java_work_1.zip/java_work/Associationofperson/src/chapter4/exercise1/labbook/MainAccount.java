package chapter4.exercise1.labbook;

public class MainAccount {
public static void main(String[] args) {
	Account ac=new Account(10000 , new Person("harish",21));
	Account bc=new Account(1000, new Person("jagan",21));
	//System.out.println(ac);
	// ac.deposit(10000);
	// System.out.println(ac);
	System.out.println("before depositing 1 "+ac.getBalance());
	System.out.println("before depositing 2 "+bc.getBalance());
	ac.withdraw(500);
	bc.withdraw(500);
	System.out.println("after withdraw 1 "+ac.getBalance());
	System.out.println("after withdraw 2 "+bc.getBalance());
	System.out.println(ac);
	System.out.println(bc);
	
}
	
}
