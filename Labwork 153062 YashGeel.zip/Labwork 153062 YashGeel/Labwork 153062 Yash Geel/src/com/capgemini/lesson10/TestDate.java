package com.capgemini.lesson10;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestDate {

	
	@Test
	public void getDate()
	{
		System.out.println("from test date");
		Date date = new Date(12, 12, 2012);
		System.out.println(date);
		assertEquals("Date is 12/12/2012", date.toString());
	}
}
