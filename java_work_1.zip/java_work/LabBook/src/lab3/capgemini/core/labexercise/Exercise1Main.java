package lab3.capgemini.core.labexercise;

import java.util.Scanner;

public class Exercise1Main {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	Exercise1 a = new Exercise1();
	System.out.println("enter some string");
	String word=sc.nextLine();
	System.out.println("enter ur choice \n");
	System.out.println(" 1. Add the string to itself \n");
	System.out.println(" 2. replace the odd positions with #\n");
	System.out.println(" 3. remove duplicate characters \n");
	System.out.println(" 4. change odd characters to upper case");
	int choice=sc.nextInt();
	StringBuffer s =new StringBuffer(word);
	switch(choice)
	{
	case 1:
		//word=word.concat(word);
		System.out.println(word.concat(word));
		//System.out.println(word);
	break;
	case 2:
		a.replace(s);
	break;
	case 3:
		a.duplicate(s);
	break;
	case 4:
		a.oddchar(s);
	}
	sc.close();
	}
	
}

