package lab3.capgemini.core.labexercise;

import java.util.Scanner;

public class Exercise2Main {
public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	System.out.println("enter some string ");
	String word=sc.nextLine();
	Exercise2 m =new Exercise2();
	boolean b =m.stringchecking(word);
	if(b == true)
	{
		System.out.println("Positive string");
	}
	else
	{
		System.out.println("negative string");
	}
	sc.close();
}
}
