package capgemini.ems.core.view;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import capgemini.ems.core.beans.Employee;
import capgemini.ems.core.exceptions.EMSException;
import capgemini.ems.core.model.EmployeeDAO;
import capgemini.ems.core.model.EmployeeDAOImp;
import capgemini.ems.core.service.EmployeeService;
import capgemini.ems.core.service.EmployeeServiceImpl;

public class Client {
	
	//loosely coupled due to use of interface
	private EmployeeService employeeservice;
	
	public Client()
	{
		//association  - linking to service
		employeeservice = new EmployeeServiceImpl();
	}
	
	public void menu()
	{
		System.out.println(" 1. Add Employee Information ");
		System.out.println(" 2. Get Employee Information ");
		System.out.println(" 3. Update Employee Information ");
		System.out.println(" 4. Remove Employee Information ");
		System.out.println(" 5. View Employee Information ");
		System.out.println(" 6. Exit application ");
		
		Scanner console = new Scanner(System.in);
		
		System.out.println("please select option:");
		int choice = console.nextInt();
		
		switch(choice)
		{
		case 1:
			 Employee employe = new Employee();
			
			System.out.println("1. enter employee name");
			
			String name = console.next();
			
			System.out.println("2. enter employee salary");
			double salary = console.nextDouble();
			
			System.out.println("3. Enter Employee department");
			String department = console.next();
			
			System.out.println("4. Enter employee date of birth (dd-mm-yyyy) ");
			String dateofbirth = console.next();
			
			System.out.println("5. Enter employee date of joining (dd-mm-yyyy) ");
			String dateofjoining=console.next();
			
			employe.setName(name);
			employe.setSalary(salary);
			employe.setDepartment(department);
			employe.setDateOfbirth(convertToDate(dateofbirth));
			employe.setDateOfbirth(convertToDate(dateofjoining));
			
			
			try {
			int empid=	employeeservice.addEmployee(employe);
				System.out.println("Employee added successfully. Employee id:"+empid);
				
			} catch (EMSException e) {
		
				e.printStackTrace();
			}catch (Exception e) {
		
				e.printStackTrace();
			}
		
			
			
			break;
		case 2:
			System.out.println("Enter Employee Id to view details");
			int empId=console.nextInt();
			
			try {
				employe = employeeservice.getEmployee(empId);
			
			
			System.out.println("ID: " +employe.getId());
			System.out.println("Name : " +employe.getName());
			System.out.println("Department: " +employe.getDepartment());
			System.out.println("Salary: " +employe.getSalary());
			System.out.println("DOB: " +employe.getDateOfbirth());
			System.out.println("DOj: " +employe.getDateOfjoining());
			} catch (EMSException e1) {
				
				e1.printStackTrace();
			} catch (Exception e1) {
				
				e1.printStackTrace();
			}
			break;
		case 3:
			//get employee details if exists
			System.out.println("Enter Employee Id to view details");
			 
			empId=console.nextInt();
			
			try {
				employe = employeeservice.getEmployee(empId);
				
				//updating name
				
				System.out.println("Employee name:"+employe.getName());
				System.out.println("Do you want to update the name(yes/no)");
				String reply =console.next();
				
				if(reply.equalsIgnoreCase("yes")) {
					System.out.println("enter the name");
					employe.setName(console.next());				
				}
				
				//updating salary
				
				System.out.println("Employee salary:"+employe.getSalary());
				System.out.println("Do you want to update the salary(yes/no)");
				 reply =console.next();
				
				if(reply.equalsIgnoreCase("yes")) {
					System.out.println("enter the salary");
					employe.setSalary(console.nextDouble());						
				}
				
				
				//updating department
				System.out.println("Employee department:"+employe.getDepartment());
				System.out.println("Do you want to update the department(yes/no)");
				 reply =console.next();
				
				if(reply.equalsIgnoreCase("yes")) {
					System.out.println("enter the Department");
					employe.setDepartment(console.next());				
				}
				
				
				//updating DOB
				System.out.println("Employee DOB:"+employe.getDateOfbirth());
				System.out.println("Do you want to update the name(yes/no)");
				 reply =console.next();
				
				if(reply.equalsIgnoreCase("yes")) {
					System.out.println("enter the DOB");
					employe.setDateOfbirth(convertToDate(console.next()));				
				}
				
				//updating DOJ
				System.out.println("Employee Joining:"+employe.getDateOfjoining());
				System.out.println("Do you want to update the name(yes/no)");
				 reply =console.next();
				
				if(reply.equalsIgnoreCase("yes")) {
					System.out.println("enter the joining");
					employe.setDateOfjoining(convertToDate(console.next()));				
				}
				
				employeeservice.updateEmployee(employe);
				System.out.println("Employee details updated successfully");
				
			
			} catch (EMSException e1) {
				
				e1.printStackTrace();
			} catch (Exception e1) {
				
				e1.printStackTrace();
			}
			
			
			
			
			//
			break;
		case 4:
			System.out.println("Enter Employee Id to view details");
			 empId=console.nextInt();
			
			try {
				employe = employeeservice.removeEmployee(empId);
			
			
			System.out.println("ID: " +employe.getId());
			System.out.println("Name : " +employe.getName());
			System.out.println("Department: " +employe.getDepartment());
			System.out.println("Salary: " +employe.getSalary());
			System.out.println("DOB: " +employe.getDateOfbirth());
			System.out.println("DOj: " +employe.getDateOfjoining());
			} catch (EMSException e1) {
				
				e1.printStackTrace();
			} catch (Exception e1) {
				
				e1.printStackTrace();
			}
			break;
		case 5:
			 
			
			try {
				List<Employee> employees =employeeservice.getAllEmployees();
				
				Iterator<Employee> it = employees.iterator();
				
				System.out.println(" ID \t Name \t Salary \t Department  \t DOb \t DOJ");
				while(it.hasNext())
				{
					Employee emp = it.next();
					
					System.out.println(emp.getId()+"\t"+
							emp.getName() + "\t"+
							emp.getSalary() + "\t"+
							emp.getDepartment() + "\t"+
							emp.getDateOfbirth() + "\t"+
							emp.getDateOfjoining() );
					
				}
				
			} catch (EMSException e) {
				
				e.printStackTrace();
			}catch (Exception e) {
				
				e.printStackTrace();
			}
			
			break;
		case 0:
			System.out.println("good bye");
			System.exit(0);
			break;
			
		default:
			System.out.println("invalid option");
			break;
		}
		
		
	}
	
	public Date convertToDate(String dateinstring)
	{
		DateTimeFormatter formater=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		
		LocalDate localdate = LocalDate.parse(dateinstring , formater);
		
		java.util.Date date = java.sql.Date.valueOf(localdate);
		
		return date;
	}
	

	public static void main(String[] args) {
		Client client = new Client();
		
		//make sure application runs forever unless you close it
		while(true)
			client.menu();
		
	}

}
