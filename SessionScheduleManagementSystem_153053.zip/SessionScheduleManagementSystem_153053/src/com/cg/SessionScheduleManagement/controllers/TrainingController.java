package com.cg.SessionScheduleManagement.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.SessionScheduleManagement.beans.ScheduledSessions;
import com.cg.SessionScheduleManagement.service.ITrainingService;

@Controller
public class TrainingController {
	
	@Autowired
	ITrainingService trainingservice;

	@RequestMapping("/")
	public ModelAndView getAllSessions()
	{
		List<ScheduledSessions> list=trainingservice.getAllSession();
		return new ModelAndView("ScheduledSessions","scheduledsessions",list);
	}

	@RequestMapping(value="/Success/{name}", method = RequestMethod.GET)
	public ModelAndView getSuccessPage(@PathVariable String name)
	{
		ScheduledSessions sessions = new ScheduledSessions();
		
		
		sessions.setName(name);
		return new ModelAndView("Success","sessions",sessions.getName());
		
	}
}
