//2.4: Modify Lab assignment 2.3 to accept phone number of a person. Create a newmethod to implement the same and also define method for displaying persondetails.
package com.capgemini.lesson2;

public class Person_24 {
	String firstName;
	String lastName;
	char gender;
	String mobile;

	public Person_24() {
		super();
		this.firstName = null;
		this.lastName = null;
		this.gender = 'x';
		this.mobile = null;

	}

	public Person_24(String firstName, String lastName, char gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		
	}

	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}
	
	public void display()
	{
		System.out.println("Person Details:");
		System.out.println("______________");
		System.out.println("\nFirst Name: " + getFirstName() );
		System.out.println("Last Name: " + getLastName());
		System.out.println("Gender: " + getGender());
		System.out.println("Mobile: "+ getMobile());
		
	}
	
	@Override
	public String toString() {
		return "Person Details:\n______________\n\nFirst Name: "
				+ getFirstName() + "\nLast Name: " + getLastName()
				+ "\nGender: " + getGender() + " ";

	}
}
