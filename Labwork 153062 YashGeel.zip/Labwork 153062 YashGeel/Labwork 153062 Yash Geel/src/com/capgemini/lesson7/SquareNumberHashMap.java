//7.4: Create a method which accepts an array of numbers and returns the numbers and their
//squares in an HashMap

package com.capgemini.lesson7;

import java.util.HashMap;
import java.util.Scanner;

public class SquareNumberHashMap {

	public HashMap<Integer, Integer> getSquares(int[] number)
	{
		HashMap<Integer, Integer> hm = new HashMap<Integer,Integer>();
		for(int i=0;i<5;i++)
		{
			hm.put(number[i], number[i]*number[i]);
		}
		return hm;
	}
	
	public static void main(String[] args) 
	{
		System.out.println("Enter 5 numbers");
		HashMap<Integer, Integer> hm = new HashMap<Integer,Integer>();
		SquareNumberHashMap sn = new SquareNumberHashMap();
		int arr[] = new int[5];
		Scanner sc = new Scanner(System.in);
		for(int i=0;i<5;i++)
		{
			arr[i] = sc.nextInt();
		}
		
		hm = sn.getSquares(arr);
		System.out.println(hm);
	}

}
