package com.capg.cms.bean;

public class Cylinderstatus {
	private  String agencyname;
	private String Location;
	private int count;
	
	public Cylinderstatus() {
		super();
	}
	
	public Cylinderstatus(String agencyname, String location, int count) {
		super();
		this.agencyname = agencyname;
		Location = location;
		this.count = count;
	}

	public String getAgencyname() {
		return agencyname;
	}

	public void setAgencyname(String agencyname) {
		this.agencyname = agencyname;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String location) {
		Location = location;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

		
	
}
