package sday;

public class Testbalance {
	public static void main(String[] args) {
		Balance object =new Balance();
		 object.balance(1200);
		 
		 
			System.out.println("bonous is successfully added"+object.balance(500) );
		
	}

}
