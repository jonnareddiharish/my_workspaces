
public class SavingAccount extends BankAccount {

}
