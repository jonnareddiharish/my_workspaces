package hashmap;
import java.util.*;
public class Hashmapdemo1 {
public static void main(String[] args) {
	HashMap<Integer, Product> employee = new HashMap();
	
	employee.put(101, new Product(101,"john",235000));
	employee.put(132, new Product(132,"randy",543000));
	employee.put(344, new Product(344,"batista",654000));
	
	//System.out.println(employee);
	
	Set entries = employee.entrySet();
	
	Iterator it = entries.iterator();
	
	while(it.hasNext())
		System.out.println(it.next());
	
	//accessing all values
	Collection values= employee.values();
	
	it=values.iterator();
	
	while(it.hasNext())
		System.out.println(it.next());
	
	//accessing keys
	
	System.out.println("");
	
	Set keys = employee.keySet();
	
	it = keys.iterator();
	
	while(it.hasNext())
	{
		System.out.println(it.next());
	
	// System.out.println(employee.get(it.next()));
	
	
}
	
	
	
}
}