package com.capgemini.core.labexercise;

public class Exercise3 {
private String fristname;
private String lastname;
private String gender;
 private long phoneNo;
public Exercise3(String fristname, String lastname, String gender, long phoneNo) {
	super();
	this.fristname = fristname;
	this.lastname = lastname;
	this.gender = gender;
	this.phoneNo= phoneNo;
}
public long getPhoneNo() {
	return phoneNo;
}
public void setPhoneNo(long phoneNo) {
	this.phoneNo = phoneNo;
}
public void setmobno(long phone){
	phoneNo=phone;
}
public String getFristname() {
	return fristname;
}
public void setFristname(String fristname) {
	this.fristname = fristname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}

}
