//11.5
package com.capgemini.lesson11.lambda;

public interface LambdaInterface_11_5 
{
	public abstract void fact(int n);
}
