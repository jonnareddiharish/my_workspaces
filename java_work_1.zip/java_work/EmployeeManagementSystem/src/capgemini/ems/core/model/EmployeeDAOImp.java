package capgemini.ems.core.model;
import capgemini.ems.core.util.*;
import capgemini.ems.*;
import java.util.List;

import capgemini.ems.core.beans.Employee;
import capgemini.ems.core.exceptions.EMSException;

public class EmployeeDAOImp implements EmployeeDAO {
	
	private List<Employee> employees;
	private DBUtil dbUtil = new DBUtil();
	
	private static int employeeId=1000;
	
	public EmployeeDAOImp()
	{
		employees = dbUtil.getEmployee();
	}
	
	public static int genetrateEmployeeId()
	{
		return ++employeeId;
	}
	
	
	@Override
	public int addEmployee(Employee employee) throws EMSException {
		//generate emp id
		//set to emp bean
		//System.out.println(employee);
		int empid= genetrateEmployeeId();
		employee.setId(empid);
		
		employees.add(employee);
		//return emp id
		return empid;
	}

	@Override
	public Employee getEmployee(int id) throws EMSException {
		
	int index =	employees.indexOf(new Employee(id));

	//employees.contains(new Employee(id));  ---- this only tells id is there or not
	if(index ==-1)
		throw new EMSException("employee not found with id"+id );
	
		return employees.get(index);
	
	}

	@Override
	public void updateEmployee(Employee employee) throws EMSException {
		int index=employees.indexOf(employee);
		if(index ==-1)
			throw new EMSException("Employee not found with id "+employee.getId());
		
		
		//employee found updating details
		Employee oldEmployee =employees.get(index);
		
		oldEmployee.setName(employee.getName());
		oldEmployee.setDepartment(employee.getDepartment());
		oldEmployee.setSalary(employee.getSalary());
		oldEmployee.setDateOfbirth(employee.getDateOfbirth());
		oldEmployee.setDateOfjoining(employee.getDateOfjoining());
		
		//updation done
		
	}

	@Override
	public Employee removeEmployee(int id) throws EMSException {
		int index=employees.indexOf(new Employee(id));
		if(index ==-1)
			throw new EMSException("Employee not found with id "+id);
		return employees.remove(index);
	}

	@Override
	public List<Employee> getAllEmployees() throws EMSException {
		// TODO Auto-generated method stub
		return employees;
	}

}
