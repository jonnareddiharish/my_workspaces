//4.4
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Differencedates {
	LocalDate d11,d21;
	public static void main(String[] args) {
		int d1,d2,month,year;
		Scanner sc = new Scanner(System.in);
		SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-DD");
		System.out.println("Enter date");
		String str = sc.nextLine();
		System.out.println("Enter other date");
		String str1 = sc.nextLine();
		LocalDate d11 = LocalDate.parse(str);
		LocalDate d21 = LocalDate.parse(str1);
		Period period = d11.until(d21);
		System.out.println("Duration between d1" + d11 + "and d2" + d21 + "is :");
		System.out.println("Days :" + period.get(ChronoUnit.DAYS));
		System.out.println("Months :" + period.get(ChronoUnit.MONTHS));
		System.out.println("Years :" + period.get(ChronoUnit.YEARS));
	}
}
