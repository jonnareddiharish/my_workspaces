package com.capgemini.assignment1.calculator;

public class TestCal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculator c1 = new Calculator();
		
		System.out.println("Adddition =" + c1.add(100,20));
		System.out.println("Adddition =" + c1.mul(10,20));
		System.out.println("Adddition =" + c1.sub(100,20));
		System.out.println("Adddition =" + c1.div(100,20));
	}

}
