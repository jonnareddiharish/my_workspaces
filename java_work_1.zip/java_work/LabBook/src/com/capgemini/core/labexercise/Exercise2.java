package com.capgemini.core.labexercise;

public class Exercise2 {
public static void main(String[] args) {
	for(int i=0; i< args.length;i++)
	{
	if(Integer.parseInt(args[0])>0)
	{
		System.out.println("positive number");
	}
	else
	{
		System.out.println("negative number");
	}
}
}}
