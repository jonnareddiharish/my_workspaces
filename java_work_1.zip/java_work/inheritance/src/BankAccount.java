
public class BankAccount {
private int accountId;
private String clientName;
private double balance;

public int getAccountId() {
	return accountId;
}
public void setAccountId(int accountId) {
	this.accountId = accountId;
}
public String getClientName() {
	return clientName;
}
public void setClientName(String clientName) {
	this.clientName = clientName;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}


public BankAccount(int accountId, String clientName, double balance) {
	super();
	this.accountId = accountId;
	this.clientName = clientName;
	this.balance = balance;
}
public void deposit(double amount)
{
	balance += amount;
}
public void withdrawl(double amount){
	if(amount>balance)
		System.out.println("Insufficient");
	return;
}
}
