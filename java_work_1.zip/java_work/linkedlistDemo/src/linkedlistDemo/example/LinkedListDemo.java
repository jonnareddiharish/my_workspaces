package linkedlistDemo.example;
import java.util.*;
public class LinkedListDemo {
	public static void main(String[] args) {
		LinkedList mylist=new LinkedList();
		mylist.add("sunday");
		mylist.add("monday");
		mylist.add("sunday");
		mylist.add(123);
		mylist.add(34.43);
		mylist.add( new Date() );
		
		//iterator
		
		Iterator it=mylist.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		//using list iterator
		
		ListIterator lit=mylist.listIterator(mylist.size());
		
		//farward direction
//		while(lit.hasNext())
//		{
//			System.out.println(lit.next());
//		}
		
		
		
		
		
		//in reverse direction
		while(lit.hasPrevious())
		{
			System.out.println(lit.previous());
		}
		
		
	}
	
	
	
	
}
