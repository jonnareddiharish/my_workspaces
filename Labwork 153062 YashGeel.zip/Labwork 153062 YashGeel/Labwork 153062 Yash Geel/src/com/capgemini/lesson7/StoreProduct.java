//7.5: Modify the above program to store product names in anArrayList, sort strings available in an arrayList and display the names using for-each loop.
package com.capgemini.lesson7;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class StoreProduct {

	public void sort(ArrayList<String> storeName)
	{
		Collections.sort(storeName);
		
		for (String string : storeName) 
		{
			System.out.println(string);
		}
		
	}
	
	
	public static void main(String[] args)
	{
		System.out.println("enter 5 products name");
		ArrayList<String> names = new ArrayList<String>();
		Scanner sc = new Scanner(System.in);
		StoreProduct sp = new StoreProduct();
		for(int i=0;i<5;i++)
		{
			names.add(sc.next());
		}
		sp.sort(names);

	}

}
