package com.capgemini.oop;

public class Polydemo {
	// SavingsAccount sa=new SavingsAccount();
BankAccount ba=new SavingsAccount();
}
