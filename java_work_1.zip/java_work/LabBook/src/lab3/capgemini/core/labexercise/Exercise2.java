package lab3.capgemini.core.labexercise;

public class Exercise2 {
	public boolean stringchecking(String str)
	{
		str = str.toUpperCase(); 
		for(int i=0;i<str.length()-1;i++)
		{
			if(str.charAt(i)>str.charAt(i+1))
			{
				return false;
				
			}
		}
		return true;
	}
}
