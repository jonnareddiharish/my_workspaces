package treeset.example;
import java.util.*;

class SortByName implements Comparator
{

	@Override
	public int compare(Object o1, Object o2) {
		Product p1=(Product)o1;
		Product p2=(Product)o2;
		return p1.getName().compareTo(p2.getName());
	}
	
}

class SortByPrice implements Comparator
{

	@Override
	public int compare(Object o1, Object o2) {
		Product p1=(Product)o1;
		Product p2=(Product)o2;
		return p1.getPrice()-p2.getPrice();
	}
	
	
	
	
	
}



public class Newdemo {

	public static void main(String[] args) {
		TreeSet products = new TreeSet(new SortByPrice());
		
		products.add(new Product(101,"dodic",200,1300));
		products.add(new Product(102,"aogtc",200,1500));
		products.add(new Product(104,"newdr",200,1800));
		
		Iterator it =products.iterator();
		
		while(it.hasNext())
		System.out.println(it.next());
		
	}
	
}




