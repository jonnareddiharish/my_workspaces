package capgemini.exercise4;

public class Firstmain {
	public static void main(String[] args) {
		
		Savingsaccount sa = new Savingsaccount("harish",100000);
		Currentaccount ca = new Currentaccount("jagan",50000);
		sa.withdraw(2000);
		System.out.println("After withdraw savings account balance is "+sa.getBalance());
		ca.withdraw(55000);
		ca.deposit(2000);
		System.out.println("After withdrawing current account balance is "+ca.showbalance());
		
	}
	
	
	
}
