//2.5: Modify the above program, to accept only �M� or �F� as gender field values. Use Enumeration for implementing the same.
package com.capgemini.lesson2;

import java.util.Scanner;

public class PersonMain_25 {

	public static void main(String[] args) {

		Person_25 person = new Person_25("Yash", "Geel");
				//
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the gender of the person");
		char ch = sc.next().charAt(0);
		if(ch=='m'||ch=='M')
		{
			person.genderCheckMale(ch);
		}
		else
		{
			if(ch=='f'||ch=='F')
			{
				person.genderCheckFemale(ch);
			}
		}
		System.out.println(person);
	}

}
