package capgemini.exercise4;

public class Savingsaccount extends Account {
	private final float minbalance=500;
	
	
	public Savingsaccount() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Savingsaccount(String name, float balance) {
		super(name, balance);
		// TODO Auto-generated constructor stub
	}


	@Override
	public void withdraw(float wtdr)
	
	{
		System.out.println("before withdraw savings account balance is "+getBalance());
		if((getBalance()-wtdr>minbalance))
		{
			setBalance(getBalance()-wtdr);
		}
		else
		{
			System.out.println("ur r drawing less than min balance");
		}
	}
	
	
	
	
	
	
	
	
}
