package com.capgemini.oop;
import java.util.*;
public class StringDemo2 {
public static void main(String[] args) {
	
	Scanner scan= new Scanner(System.in);
	System.out.println("enter ur mail");
	String email = scan.next();
	String[] arr = email.split("@");
	System.out.println(arr[0]);
	
	int index = email.indexOf("@");
	String subString = email.substring(0, index);
	System.out.println(subString);
	
}
}
