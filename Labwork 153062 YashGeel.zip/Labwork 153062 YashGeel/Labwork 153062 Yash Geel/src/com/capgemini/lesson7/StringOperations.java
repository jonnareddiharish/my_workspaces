//7.2: Create a method which can perform the following operations on two String objects S1 and
//S2. The output of each operation should be added to an arraylist and the arraylist should be
//Returned (Assume S2 is of smaller size)
//Examples for below statements are shown in the Logic part
//1. Character in each alternate index of S1 should be replaced with S2
//2. If S2 appears more than once in S1, replace the last occurrence of S2 in S1 with the reverse of S2,else return S1+S2
//3. If S2 appears more than once in S1, delete the first occurrence of S2 in S1, else return S1
//4. Divide S2 into two halves and add the first half to the beginning of the S1 and second half to the end of S1.
//Note: If there are odd number of letters in S2, then add (n/2) +1 letters to the beginning and
//remaining letters to the end.(n is the number of letters in S2)
//5. If S1 contains characters that is in S2 change all such characters to *


package com.capgemini.lesson7;

import java.util.ArrayList;
import java.util.Scanner;

public class StringOperations
{

	public ArrayList<String> stringFunctions(String str1, String str2)
	{
		
		ArrayList<String> al = new ArrayList<String>();
		int len1 = str1.length();
		int len2 = str2.length();
		String temp = "";
		
		
		
		
		
		// operation1
		int i=0,j=0,flag=0;
		for(i=0;i<len1;i++)
		{	if(i%2==0)
			{
				temp = temp + str1.charAt(i);
			}
			else
			{
				if(j<len2)
				{
					temp = temp + str2.charAt(j);
					j++;
				}
				else
				{
					flag=1;
					break;
				}
				
			}
			
		}
		for(j=i;j<len1;j++)
		{
			temp = temp + str1.charAt(j);
		}
		al.add(temp);
		
		
		
		
		
		
		//operation2
		temp="";
		String reverse = "";
		int f = str1.lastIndexOf(str2);
		if(f==-1)
		{
			al.add(str1+str2);
		}
		else
		{
			for(i=0;i<f;i++)
			{
				temp = temp + str1.charAt(i);
			}
			
			for(j = str2.length()-1 ; j>=0;j--)
			 {
				 temp = temp + str2.charAt(j);
			 }
			
			for(j=i+len2;j<len1;j++)
			{
				temp = temp + str1.charAt(j);
			}
			al.add(temp);
		}
		
		
		
		
		
		// Operation3
		temp="";
		
		f = str1.indexOf(str2);
		if(f==-1)
		{
			al.add(str1);
		}
		else
		{
			for(i=0;i<f;i++)
			{
				temp = temp + str1.charAt(i);
			}
			
			for(j = str2.length()-1 ; j>=0;j--)
			 {
				 temp = temp + str2.charAt(j);
			 }
			
			for(j=i+len2;j<len1;j++)
			{
				temp = temp + str1.charAt(j);
			}
			al.add(temp);
		}
		
		
		
		
		//Operation4
		temp = "";
		if(len2%2==0)
		{
			temp = temp + str2.substring(0, len2/2);
			temp = temp + str1;
			temp = temp + str2.substring(len2/2 , len2);
		}
		else
		{
			temp = temp + str2.substring(0, len2/2+1);
			temp = temp + str1;
			temp = temp + str2.substring(len2/2 + 1, len2);
		}
		al.add(temp);
		
		
		
		
		
		//Operation5
		temp = "";
		for(i=0;i<len1;i++)
		{ flag=0;
			for(j=0;j<len2;j++)
			{
				if(str1.charAt(i)==str2.charAt(j))
				{
					flag=1;
					break;
				}
			}
			if(flag==1)
			{
				temp = temp + "*";
			}
			else
			{
				temp = temp + str1.charAt(i);
			}
		}
		al.add(temp);
		
		
		return al;
		
	}
	
	public static void main(String[] args) 
	{
		System.out.println("***sample input test case to understand the problem easily. 'helloworldhello' and 'ello' ****");
		Scanner sc = new Scanner(System.in);
		StringOperations so = new StringOperations();
		System.out.println("enter the first string");
		String str1 = sc.next();
		System.out.println("enter the second string ");
		String str2 = sc.next();
		ArrayList< String > str ;		
		str = so.stringFunctions(str1, str2);
		System.out.println(str);
	}

}
