//11.3
package com.capgemini.lesson11.lambda;

public interface LambdaInterface_11_3 
{
	public abstract boolean validation(String userName, String password);
}
