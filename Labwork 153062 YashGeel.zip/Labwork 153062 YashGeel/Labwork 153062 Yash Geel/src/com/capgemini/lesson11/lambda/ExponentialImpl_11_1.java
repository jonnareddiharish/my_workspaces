//11.1: Write a lambda expression which accepts x and y numbers and return xy.
package com.capgemini.lesson11.lambda;

public class ExponentialImpl_11_1 
{
	
	public static void main(String[] args) {
		
	
	ExponentialInterface_11_1 exp = (n1 , n2) -> 
									{  
										String temp1 ="" + n1;
										String temp2 = "" + n2;
										
									return Math.pow(Double.parseDouble(temp1), Double.parseDouble(temp2));	
									};
	System.out.println(exp.exp(10, 2));
									
	}
	
}
