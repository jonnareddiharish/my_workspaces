package com.capgemini.core.labexercise;

public class EnumDemo {
 String fname,lname;
 int age;
 double weight;
 enum gender{
	 M,f
 };
 gender gen;
 
public EnumDemo(String fname, String lname, int age, double weight, char gen) {
	super();
	this.fname = fname;
	this.lname = lname;
	this.age = age;
	this.weight = weight;
	if(gen =='M'||gen =='m')
	{
		this.gen=gender.M;
	}
	else if(gen == 'F'||gen == 'f')
	{
		this.gen=gender.f;
	}
}
 public void display()
 {
	 System.out.println("person details\n -----------\n");
	 System.out.println("Name:"+fname.concat(lname));
	 System.out.println("Age:"+ age);
	 System.out.println("Gender:"+ gen);
 }
	
	
	
}
