package com.capgemini.oop;
import java.util.Scanner;
public class StringManipulations {
	public static void main(String[] args) {
		
	Scanner sc = new Scanner(System.in);
	System.out.println("enter some string ");
	String str = sc.nextLine();
	String[] words =str.split(" ");
	System.out.println("word count" + words.length);
	 
	int noofspaces = words.length-1;
	System.out.println("char length is" + (str.length()-noofspaces));
	
}
}