package capgemini.exercise4;

public class Currentaccount extends Account {
	private float overdraftlimit;
	
	public void withdraw(float wtdr)
	{   System.out.println("before withdraw current account balance is "+getBalance());
		overdraftlimit = (float) (1.1*getBalance());
		//System.out.println(overdraftlimit);
		//System.out.println("working");
		if(wtdr<=overdraftlimit)
		{
			setBalance(getBalance()-wtdr);
		}
		else
		{
			System.out.println("over draft limit exceded");
		}
		
	}

	public float showbalance()
	{
		if(getBalance()<0)
		{
			return 0;
		}
		else
		{
			return getBalance();
		}
		
	}
	
	public Currentaccount() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Currentaccount(String name, float balance) {
		super(name, balance);
		// TODO Auto-generated constructor stub
	}
	
	
}
