package treeset.example;
import java.util.*;





public class TreesetDemo {
public static void main(String[] args) {
	TreeSet names = new TreeSet();
	
	names.add("john");
	names.add("peter");
	names.add("marc");
	names.add("antony");
	names.add("eric");
	names.add("eric");
	
	TreeSet phoneno = new TreeSet();
	phoneno.add(9765474474l);
	phoneno.add(976765475654l);
	phoneno.add(9765439875l);
	phoneno.add(97654749879l);
	
	//printing
	Iterator it =names.iterator();
	
	while(it.hasNext())
	{
		System.out.println(it.next());
	}
	
	System.out.println("");
	
	it = phoneno.iterator();
	
	while(it.hasNext())
		System.out.println(it.next());
	
	
}
	
	
	
	
}
