//4.1
package chapter4.exercise1.labbook;

import java.util.Random;

public class Account {
private int accNum;
private double balance=0;
private Person accHolder;

public Account( double balance, Person accHolder) {
	super();
	Random rn = new Random();
	this.accNum = rn.nextInt();
	this.balance = balance;
	this.accHolder = accHolder;
}


public int getAccNum() {
	return accNum;
}




public void setAccNum(int accNum) {
	this.accNum = accNum;
}




public double getBalance() {
	return balance;
}




public void setBalance(double balance) {
	this.balance = balance;
}




public Person getAccHolder() {
	return accHolder;
}


public void setAccHolder(Person accHolder) {
	this.accHolder = accHolder;
}





@Override
public String toString() {
	return "Account [accNum=" + accNum + ", balance=" + balance + ", accHolder=" + accHolder + "]";
}




public void deposit(double amount)
{
	balance+=amount;
}

public void withdraw(double amount)
{
	balance-=amount;
}

}
