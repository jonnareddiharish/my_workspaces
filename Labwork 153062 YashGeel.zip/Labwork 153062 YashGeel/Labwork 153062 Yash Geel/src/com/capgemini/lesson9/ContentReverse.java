//9.1: Write a program to read content from file, reverse the content and write the reversed content to the file. (Use Reader and Writer APIs).

package com.capgemini.lesson9;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ContentReverse 
{

	public static void main(String[] args) throws IOException 
	{
		FileInputStream fromFile;
		FileOutputStream toFile ;
		String fileName = "D:\\Labwork 153062 YashGeel\\Labwork 153062 Yash Geel\\src\\com\\capgemini\\lesson9\\source.txt";
		String fileName1 = "D:\\Labwork 153062 YashGeel\\Labwork 153062 Yash Geel\\src\\com\\capgemini\\lesson9\\target.txt";
		fromFile = new FileInputStream(fileName);
		toFile = new FileOutputStream(fileName1);
		int i = fromFile.read();
		int  count = 0;
		
		String st ="" + (char)i;
		
		while (i != -1) { //check the end of file
			//toFile.write(i);
			
			i = fromFile.read();
			st = st + (char)i;
		}
		
		for(int j=st.length()-2;j>=0;j--)
		{
			
			int k = st.charAt(j);
			toFile.write(k);
		}
		System.out.println(st);
	}
}
