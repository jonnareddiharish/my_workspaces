//6.3: Modify the Lab assignment 5.1 to handle exceptions. Create an Exception class named as �EmployeeException�(User defined Exception) in a package named as �com.cg.eis.exception� and throw an exception if salary of an employee is below than 3000. Use Exception Handling mechanism to handle exception properly.

package com.capgemini.lesson6.eis.exception;

import java.util.Scanner;

class myException2 extends Exception
{
	public String getMessage()
	{
		return "Entered Salary is less than 3000";
	}
}


public class EmployeeException 
{
	public static void main(String[] args) throws myException2 
	{
		System.out.println("enter the salary of the employee");
		Scanner sc = new Scanner(System.in);
		double salary = sc.nextDouble();
		sal(salary);
	}
	
	public static void sal(double salary) throws myException2
	{
		
		if(salary<3000)
		{
			throw new myException2();
		}
		else
		{
			System.out.println("salary is :- " + salary);
		}
	}
}
