package com.capgemini.core.oop.relation;

public interface TvRemote  extends Remote
{
	public void changeVolume();
	public void changeChannel();
}
