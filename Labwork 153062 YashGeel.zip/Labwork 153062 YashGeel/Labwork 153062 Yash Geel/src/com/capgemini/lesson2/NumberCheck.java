//2.2: Write a program to accept a number from user as a command line argument and check whether the given number is positive or negative number.

package com.capgemini.lesson2;

public class NumberCheck {

	public static void main(String[] args) {
		
		int number = Integer.parseInt(args[0]);
		if (number < 0)
			System.out.println("Number is negative.");
		else
			System.out.println("Number is positive.");

	}

}
