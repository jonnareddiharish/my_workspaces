//11.4: Write a class with main method to demonstrate instance creation using method reference. (Hint: Create any simple class with attributes and getters and setters)
package com.capgemini.lesson11.lambda;

class LambdaImpll_11_4 implements LambdaInterface_11_4
{
	int age;
	String name;
	int id;
	
	
	public LambdaImpll_11_4(int age, String name, int id) {
		super();
		this.age = age;
		this.name = name;
		this.id = id;
		Person_11_4 per = new Person_11_4(age, name, id);
		System.out.println(per);
		
	}



	@Override
	public LambdaImpll_11_4 getLambdaImpll_11_4(int id, String name, int age) {
		return null;
	}

}


public class LambdaImpl_11_4
{
	public static void main(String[] args) 
	{
	
			LambdaInterface_11_4 lm = LambdaImpll_11_4::new; 
			lm.getLambdaImpll_11_4(21, "yash", 101);
			
		

		
	}
}