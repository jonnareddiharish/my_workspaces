package com.cg.SessionScheduleManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.SessionScheduleManagement.DAO.ITrainingDAO;
import com.cg.SessionScheduleManagement.beans.ScheduledSessions;

@Component(value="trainingservice")
public class TrainingServiceImpl implements ITrainingService{

	@Autowired
	ITrainingDAO dao;
	@Override
	public List<ScheduledSessions> getAllSession() {
		List<ScheduledSessions> sessionlist=dao.findAll();
		return sessionlist;
	}

}
