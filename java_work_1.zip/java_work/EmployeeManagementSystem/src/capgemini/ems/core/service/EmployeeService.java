package capgemini.ems.core.service;

import java.util.List;

import capgemini.ems.core.beans.Employee;
import capgemini.ems.core.exceptions.EMSException;

public interface EmployeeService {


	public int addEmployee(Employee employee)throws EMSException;
	public Employee getEmployee(int id)throws EMSException;
	public void updateEmployee(Employee employee)throws EMSException;
	public Employee removeEmployee(int id)throws EMSException;
	public List<Employee> getAllEmployees()throws EMSException;
	
	//new method
	public boolean isvalid(Employee employee) throws EMSException;
	
	
	
	
	
}
