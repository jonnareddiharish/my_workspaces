//11.2
package com.capgemini.lesson11.lambda;

public interface LambdaInterface_11_2 
{
	public abstract String modifyString(String str);
}
