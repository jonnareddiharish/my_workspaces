package com.capgemini.oop;

public abstract class BankAccount {
	private int accountid;
	private String name;
	private int balance;
	public BankAccount() {
		super();
	}
	public BankAccount(int accountid, String name, int balance) {
		super();
		this.accountid = accountid;
		this.name = name;
		this.balance = balance;
	}
	public abstract void displayAccount();
	
	public int getAccountid() {
		return accountid;
	}
	public void setAccountid(int accountid) {
		this.accountid = accountid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}

}
