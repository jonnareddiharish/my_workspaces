package holder;

public class GenricsDemo {
	public static void main(String[] args) {
		
		Holder<String> names = new Holder();
		
		names.add("jagan");
		names.add("harish");
		
		System.out.println(names.get(0));
		System.out.println(names.get(1));
		
		Holder<Integer> nums = new Holder();
		nums.add(343);
		nums.add(233);
		nums.add(9876);
		System.out.println(nums.data);
	}
	
	
	
	
}
