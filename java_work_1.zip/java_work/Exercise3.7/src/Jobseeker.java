
import java.util.Scanner;

public class Jobseeker {
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your name");
		String str = sc.next();
		Jobseeker js = new Jobseeker();
		boolean b = js.add_job(str);
		System.out.println(b);
		sc.close();
	}

	boolean add_job(String str) {
		if (str.length() < 8)
			return false;
		else
		{
			System.out.println(" The valid strin : " +str+ "_job");
			return true;
		}
	}
}