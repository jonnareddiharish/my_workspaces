package capgemini.exercise4;

public class Account {
	private final int id;
	private String name;
	private float balance;
	
	public static int counter=0;
	
	
	public Account() {
		super();
		id=++counter;
	}

	public Account(String name, float balance) {
		super();
		id=++counter;
		this.name = name;
		this.balance = balance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public int getId() {
		return id;
	}
	
	@Override
	public String toString() {
		return "Account [id=" + id + ", name=" + name + ", balance=" + balance + "]";
	}

	public void deposit(float dep)
	{
		balance=balance+dep;
	}
	
	public void withdraw(float wtdr)
	{
		if(wtdr<balance)
		{
			balance=balance-wtdr;
		}
		else
		{
			System.out.println("insufficient balance");
		}
	}
	
}
