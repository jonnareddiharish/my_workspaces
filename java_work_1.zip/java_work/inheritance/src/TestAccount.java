
public class TestAccount {
public static void main(String[] args) {
	BankAccount sa= new BankAccount();
	
	sa.setAccountId(100);
	
}
}
