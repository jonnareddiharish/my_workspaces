//5.2: Use overrides annotation for the overridden methods available in a derived class of an interface of all the assignments.
// this program can be called from EmployeeMain Class of service package.
package com.capgemini.lesson5.eis.pl;

import com.capgemini.lesson5.eis.bean.Employee;

public class EmployeeService implements EmployeeServiceInterface 
{

	@Override
	public void insuranceCalc(Employee emp) 
	{
		if(emp.getEmpSalary()<5000)
		{
			emp.setEmpInsuranceScheme("No Scheme");
		}
		
		if(emp.getEmpSalary()>5000 && emp.getEmpSalary()<20000 )
		{
			emp.setEmpInsuranceScheme("Scheme C");
		}
		
		if(emp.getEmpSalary()>=20000 && emp.getEmpSalary()<40000 )
		{
			emp.setEmpInsuranceScheme("Scheme B");
		}
		
		if(emp.getEmpSalary()>=40000)
		{
			emp.setEmpInsuranceScheme("Scheme A");
		}
	}

}
