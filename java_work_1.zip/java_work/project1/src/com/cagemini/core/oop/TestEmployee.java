package com.cagemini.core.oop;

public class TestEmployee {

	public static void main(String[] args) {
		//Declaration
		Employee emp1 =null;
		//Instantiation
		emp1 = new Employee();
		 Employee.company="capgemini";
		//initialization
		//emp1.id =101;
		//emp1.name ="john";
		//emp1.salary=1234;
		
		//System.out.println("id :" + emp1.id);
		//System.out.println("name :" + emp1.name);
		//System.out.println("salary :" + emp1.salary);
		emp1.setId(1000);
		emp1.setName("harish");
		emp1.setSalary(10000);
		
		System.out.println(emp1.getId());
		System.out.println(emp1.getName());
		System.out.println(emp1.getSalary());
		System.out.println(emp1.getCompany() );
		
	}
	
}
