package com.capgemini.capstore.controllers;

public class URIController {
	

}
