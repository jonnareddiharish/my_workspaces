package com.capgemini.oop;

public class TestAccount {
public static void main(String[] args) {
	SavingsAccount sa= new SavingsAccount();
	sa.setAccountid(1000);
	sa.setName("harish");
	sa.setBalance(50000);
	System.out.println("balance is" + sa.getBalance());
	System.out.println("your name is" + sa.getName());
	
	
}
}
