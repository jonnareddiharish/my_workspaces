package com.capgemini.core.labexercise;

public class Exercise1 {
public static void main(String[] args) {
	String firstname ="Divya";
	String lastname ="Bharathi";
	String gender ="F";
	double weight=85.55;
	System.out.println("PersonDetails"+"\n"+"---------");
	System.out.println("Firstname: " + firstname + "\n" + "lastname: "+ lastname + "\n"+ "Gender: "+ gender +"\n"+ "weight: "+weight);
}
}
