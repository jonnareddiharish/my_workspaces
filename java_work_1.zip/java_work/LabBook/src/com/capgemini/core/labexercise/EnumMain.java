package com.capgemini.core.labexercise;

public class EnumMain {

	public static void main(String[] args) {
		EnumDemo de=new EnumDemo("hari","jagan",10,20,'m');
		de.display();
	}
}
