//3.2: Create a method that accepts a String and checks if it is a positive string. A string is considered a positive string, if on moving from left to right each character in the String comes after the previous characters in the Alphabetical order.For Example: ANT is a positive String (Since T comes after N and N comes after A). The method should return true if the entered string is positive.
package com.capgemini.lesson3;

import java.util.Scanner;

public class StringCheck {

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the string");
		String str = sc.next();
		str = str.toUpperCase();
		int flag=0;
		for(int i=0;i<str.length()-1;i++)
		{
			if(str.charAt(i)>str.charAt(i+1))
			{
				flag=1;
				break;
			}
		}
		if(flag==0)
		{
			System.out.println("Entered String is positive");
		}
		else
		{
			System.out.println("Entered String is negative");
		}

	}

}
