//8.1: Write a program to do the following operations using Thread:
// Create an user defined Thread class called as �CopyDataThread .java�.
// This class will be designed to copy the content from one file �source.txt � to another file �target.txt� and after every 10 characters copied, �10 characters are copied� message will be shown to user.(Keep delay of 5 seconds after every 10 characters read.)
// Create another class �FileProgram.java� which will create above thread.Pass required File Stream classes to CopyDataThread constructor and implement the above functionality.


package com.capgemini.lesson8;

public class FileProgram {

	public static void main(String[] args)
	{
		
		CopyDataThread c1 = new CopyDataThread();
		Thread t1 = new Thread(c1);
		t1.start();
		
	}

}
