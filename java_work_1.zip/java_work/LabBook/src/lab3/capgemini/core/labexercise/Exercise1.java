package lab3.capgemini.core.labexercise;

public class Exercise1 {
	String word = "";
	int flag;

	public void replace(StringBuffer str)
	{
		for(int i=0;i<str.length();i++)
		{
			if(i%2==0){

				str.replace(i, i+1,"#");
			}
		}
		
	}
	public void duplicate(StringBuffer str){
		for(int i=0;i<str.length()-1;i++)
		{
			for(int j=i+1;j<str.length();j++)
			{
				
				if(str.charAt(i) == str.charAt(j))
				{
					str.deleteCharAt(j);
					j--;
				}
			}
		}
		System.out.println(str);
		
	}
	
	public void oddchar(StringBuffer str)
	{
		for(int i=0;i<str.length()-1;i++)
		{
		if(i%2==0)
		{
			char a=str.charAt(i); 
			String b=Character.toString(a);
			String c=b.toUpperCase();
		    str.replace(i, i+1, c);
		    System.out.println(str);
			
		}
		}
	}
	
}
