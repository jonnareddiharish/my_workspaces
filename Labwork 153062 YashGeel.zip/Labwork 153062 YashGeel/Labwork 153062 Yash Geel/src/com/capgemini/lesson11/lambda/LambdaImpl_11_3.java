//11.3: Write a method that uses lambda expression to accept username and password and return true or false. (Hint: Use any custom values for username and password for authentication)

package com.capgemini.lesson11.lambda;

import java.util.Scanner;

public class LambdaImpl_11_3
{
	public static void main(String[] args) {
		
	
	
	LambdaInterface_11_3 lm = (userName, password ) ->
								{
									if(userName.equalsIgnoreCase("ADMIN") && password.equals("Admin@123"))
										return true;
									else
										return false;
								};
			Scanner sc = new Scanner(System.in);
			System.out.println("Custom username is ADMIN and password is Admin@123");
			System.out.println("enter the username");
			String uName = sc.next();
			System.out.println("enter the password");
			String pass = sc.next();
			
			System.out.println(lm.validation(uName, pass));
								
	}
}
