//3.7 : You are asked to create an application for registering the details of jobseeker. The
//requirement is:
//Username should always end with _job and there should be atleast minimum of 8 characters to the left
//of _job. Write a function to validate the same. Return true in case the validation is passed. In case of
//validation failure return false.

package com.capgemini.lesson3;

import java.util.Scanner;

import javax.swing.text.StyledEditorKit.BoldAction;

public class StringValidation 
{
	//String userName;
	
	public Boolean validation(String userName)
	{
		int len = userName.length();
		if(len<12)
			return false;
		if(!userName.endsWith("_job"))
			return false;
		return true;
	}
	
	public static void main(String[] args)
	{
		
		StringValidation sv = new StringValidation();
		System.out.println("enter the username");
		Scanner sc = new Scanner(System.in);
		String uName = sc.next();
		System.out.println(sv.validation(uName));
		
	}
}
