//11.4
package com.capgemini.lesson11.lambda;

public interface LambdaInterface_11_4
{
	public abstract LambdaImpll_11_4 getLambdaImpll_11_4(int id , String name , int age);
}
