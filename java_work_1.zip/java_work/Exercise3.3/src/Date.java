
//3.3

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Date {

	LocalDate da;
	public static void main(String[] args) {
		int da, month, year;
		Scanner sc= new Scanner(System.in);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		System.out.println("Enter the date in dd/mm/yyyy ");
		String text = sc.next();
		LocalDate startdate=LocalDate.parse(text, formatter);
		LocalDate endDate=LocalDate.now();
		Period period = startdate.until(endDate);
		System.out.println("Days:" +period.get((ChronoUnit.DAYS)));
		System.out.println("Months:" +period.get((ChronoUnit.MONTHS)));
		System.out.println("Years:" +period.get((ChronoUnit.YEARS)));
	}
}