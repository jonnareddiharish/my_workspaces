package capgemini.ems.core.service;

import java.util.List;

import capgemini.ems.core.beans.Employee;
import capgemini.ems.core.exceptions.EMSException;
import capgemini.ems.core.model.EmployeeDAO;
import capgemini.ems.core.model.EmployeeDAOImp;

public class EmployeeServiceImpl implements EmployeeService {
	
	
	private EmployeeDAO empDAO;
	public EmployeeServiceImpl()
	{
		empDAO = new EmployeeDAOImp();
	}
	
	
	@Override
	public int addEmployee(Employee employee) throws EMSException {
		
		int empId=0;
		
		if(isvalid(employee))
		empId= empDAO.addEmployee(employee);
		
		return empId;
	}

	@Override
	public Employee getEmployee(int id) throws EMSException {
		
		Employee employee = null;
		employee = empDAO.getEmployee(id);
		
		return employee;
	}

	@Override
	public void updateEmployee(Employee employee) throws EMSException {
		empDAO.updateEmployee(employee);
		
		
	}

	@Override
	public Employee removeEmployee(int id) throws EMSException {
		Employee employee=null;
		
		employee = empDAO.removeEmployee(id);
		return employee;
	}

	@Override
	public List<Employee> getAllEmployees() throws EMSException {
		List<Employee> employees = null;
		
		employees = empDAO.getAllEmployees();
		
		return employees;
	}

	public boolean isvalid(Employee employee) throws EMSException {
		
		
		return true;
	}

}
