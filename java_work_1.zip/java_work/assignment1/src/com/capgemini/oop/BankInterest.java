package com.capgemini.oop;

public interface BankInterest {
void calcInterest();
}
