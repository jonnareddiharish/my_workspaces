package com.capgemini.core.labexercise;
import java.util.*;
public class PersonMain {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter mob number");
	long num= sc.nextLong();
	Exercise3 sa=new Exercise3("hari","j","m",num);
	
System.out.println("Firstname: "+ sa.getFristname());
System.out.println("lastname: "+ sa.getLastname());
System.out.println("Gender: "+ sa.getGender());
System.out.println("Mobilenumber: "+ sa.getPhoneNo());
sc.close(); 
}
}
