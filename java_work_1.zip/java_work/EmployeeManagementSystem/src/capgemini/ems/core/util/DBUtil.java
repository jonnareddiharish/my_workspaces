package capgemini.ems.core.util;
import java.util.*;
import capgemini.ems.core.beans.Employee;


public class DBUtil {
	private List<Employee> employee = new ArrayList<Employee>();
	{
		
		employee.add(new Employee(101,"jagan",25000,"cse",null,null));
		employee.add(new Employee(102,"juan",75000,"ece",null,null));
	}
	public List<Employee> getEmployee() {
		return employee;
	}
	public void setEmployee(List<Employee> employee) {
		this.employee = employee;
	}
	
	
	
}
