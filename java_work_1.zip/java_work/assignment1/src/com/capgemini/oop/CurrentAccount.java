package com.capgemini.oop;

public class CurrentAccount extends BankAccount implements BankInterest {
public void calcInterest(){
	
}
public void displayAccount(){
	
}
}
