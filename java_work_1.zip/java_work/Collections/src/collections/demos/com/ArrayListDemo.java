package collections.demos.com;
import java.util.*;

class Product
{
	private int id;
	private String name;
	private float price;
	
	public Product(int id) {
		super();
		this.id = id;
	}

	public Product(int id, String name, float price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price
				+ "]";
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (id != other.id)
			return false;
		return true;
	}
	
	
	
}


public class ArrayListDemo {
public static void main(String[] args) {
	ArrayList mylist = new ArrayList();
	
	mylist.add("sunday");
	mylist.add("monday");
	mylist.add("sunday");
	mylist.add(new Integer(123)); //boxing
	mylist.add(12.5);//autoboxing
	mylist.add(new Date());
	mylist.add(new Product(101,"sony",12000));
	System.out.println(mylist);
	
	
/*	for(int index=0;index< mylist.size();index++)
	{
		Object obj=mylist.get(index);
		if(obj instanceof String)
		{
			String s=(String)obj;
			System.out.println(s.toUpperCase());
		}
		else
			System.out.println(obj);
	}
	
	
	for(Object object : mylist){
		System.out.println(object);
	}
	
	
	Iterator it=mylist.iterator();
	while(it.hasNext())
	{
		Object obj=it.next();
	//	mylist.add("hello");
		System.out.println(obj);
	}
	
	
	//to check whether element is present
	if(mylist.contains("sunday"))
	{
		System.out.println("exists");
	}
	else
	{
		System.out.println("does not exists");
	}
	
	
	
	
	//searching
	mylist.get(1);
	int index1 = mylist.indexOf("monday");
	if(index !=-1)
	{
		String s =(String) mylist.get(index);
	}
	
	
	//update
	String s = (String)mylist.get(1);
	s = s.toUpperCase();
	mylist.remove(1);
	mylist.add(1, s);
	System.out.println(mylist);
	
	*/
	
	///updation
	int index = mylist.indexOf(new Product(101));
	Product p = (Product)mylist.get(index);
	p.setPrice(18000);
	System.out.println(mylist);
	
	
	//remove object
	//mylist.remove(0);
	
	//bytype
	//mylist.remove("monday");
	
}
}
