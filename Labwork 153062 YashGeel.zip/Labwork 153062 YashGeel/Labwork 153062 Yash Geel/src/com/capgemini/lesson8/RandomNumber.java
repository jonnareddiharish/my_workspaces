//8.3: Write a Java Program, where one thread prints a number (Generate a random number using Math.random()) and another thread prints the factorial of that given number. Both the outputs should alternate each other.
//E.g.: Number: 2
//Factorial of 2: 2
//Number: 5
//Factorial of 5: 120

package com.capgemini.lesson8;

import java.util.Random;

class Runnable1 implements Runnable
{

	
	public int n;
	
	
	
	public Runnable1() {
		super();
	}

	public Runnable1(int n)
	{
		this.n = n;
	}
	
	 public void generate() throws InterruptedException
	{
		 
		
		Random t =new Random();
		n=t.nextInt(10);
		System.out.println("number is :- "+ n);
		
	}
	
	@Override
	public void run() 
	{
	
		try {
			generate();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}
}

class Runnable2 implements Runnable
{
	
	public int c;
	
	
	
	public Runnable2(int c) {
		super();
		this.c = c;
	}

	static public void fact(int n) throws InterruptedException
	{
		
		
		int fact=1;
		if(n==0)
			fact = 0;
		for(int i=1;i<=n;i++)
		{
			fact = fact * i;
		
		}
		System.out.println("factorial is :- "+ fact);
		
	
	}
	
	@Override
	public void run() 
	{
		try {
			fact(c);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		
	}
}


public class RandomNumber 
{
	static int n;
	public static void main(String[] args) throws InterruptedException
	{
		
		for(int  i=0;i<5;i++)
		{
				Runnable1 r1 = new Runnable1();
				
				Thread t1 = new Thread(r1);
				
				t1.start();
				
				Thread.sleep(800);
				Runnable2 r2 = new Runnable2(r1.n);
				Thread t2 = new Thread(r2);
		
				
				t2.start();
				Thread.sleep(800);
		}	
	}
	
}
