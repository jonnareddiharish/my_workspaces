package sday;

public class Balance {
	 String name;
	 double balance;
	
	
	public double balance(double balance) {
		
		if(balance>0) {
		
			balance=balance+1000;
			System.out.println("sufficent balance"+ balance);
		}
	return 	balance;
	}

}
