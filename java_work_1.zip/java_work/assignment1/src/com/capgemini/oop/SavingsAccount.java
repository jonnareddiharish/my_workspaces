package com.capgemini.oop;

public class SavingsAccount extends BankAccount {
 int balance;
 private boolean isSalaryAccount;
// int accountid;
// String name;
	public SavingsAccount()
{
}
public SavingsAccount(int balance, int accountid, String name, boolean isSalaryAccount)
{
	super();
	//this.balance=balance;
	//this.accountid=accountid;
	//this.name=name;
}
public boolean isSalaryAccount() {
	return isSalaryAccount;
}
public void setSalaryAccount(boolean isSalaryAccount) {
	this.isSalaryAccount = isSalaryAccount;
}
public void displayAccount(){
System.out.println("this is savings account");	
}
}



