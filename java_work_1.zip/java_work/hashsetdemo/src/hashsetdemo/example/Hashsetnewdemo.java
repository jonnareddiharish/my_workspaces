package hashsetdemo.example;
import java.util.*;
public class Hashsetnewdemo {

	public static void main(String[] args) {
		
		HashSet product = new HashSet();
		
		
		product.add(new Product(101,"sony",100,23_000));
		product.add(new Product(102,"dell",300,30_000));
		product.add(new Product(102,"dell",300,30_000));
		
		Iterator it=product.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		
	}
	
}
