//2.3: Refer the class diagram given below and createa personclass
package com.capgemini.lesson2;

public class PersonMain {

	public static void main(String[] args) {
		
		Person person = new Person("Yash","Geel",'M');
				System.out.println(person);
		
		

	}

}
