package com.capgemini.core.labexercise;

enum gender
{
	M,F;
}


public class Exercise4 {
	
	
}
