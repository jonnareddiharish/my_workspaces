package com.capg.cms.exceptions;

public class CMSException {

}
