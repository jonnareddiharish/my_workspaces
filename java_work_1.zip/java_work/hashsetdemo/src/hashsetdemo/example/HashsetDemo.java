package hashsetdemo.example;
import java.util.*;
public class HashsetDemo {
	public static void main(String[] args) {
		HashSet myset = new HashSet();
		
		myset.add("hello");
		myset.add("monday");
		myset.add("trinity");
		myset.add("john");
		myset.add("Hello");
		
		Iterator it =myset.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		
		
	}
	
	
}
